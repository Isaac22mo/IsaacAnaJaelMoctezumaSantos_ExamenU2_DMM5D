import { Text } from "react-native";

Mas = () =>{
    return (
      <Text>Hola</Text>
    );
  }
  
  export default Mas; 