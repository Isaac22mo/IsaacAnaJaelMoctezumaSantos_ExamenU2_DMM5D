import { SearchBar } from "@rneui/base";
import { Image } from "@rneui/themed";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";

Buscar = () =>{
  const [search, setSearch] = useState("");
  
  const updateSearch = (search) => {
    setSearch(search);
  };

return (
  <View style={{flex:1, alignContent:'center', marginTop:35, width:'100%', backgroundColor:'white'}}>
  <View style={{backgroundColor:'blue', marginBottom:10}}>
    <SearchBar
      placeholder="Buscar"
      onChangeText={updateSearch}
      value={search} style={{ height:10,borderRadius:15, backgroundColor:'white',marginLeft:5}}
    />
  </View>


   <View style={{flexDirection:'row'}}>
                    <Image style={{ width: 120, height: 150, margin:2 }} source={{uri:'https://i0.wp.com/irreverentemusic.com/wp-content/uploads/2020/09/jose-madero-2-1200x1200-1.jpg?resize=940%2C940&ssl=1'}} />
                    <Image style={{ width: 120, height: 150, margin:2 }} source={{uri:'https://i0.wp.com/irreverentemusic.com/wp-content/uploads/2020/09/jose-madero-2-1200x1200-1.jpg?resize=940%2C940&ssl=1'}} />
                    <Image style={{ width: 120, height: 150, margin:2 }} source={{uri:'https://i0.wp.com/irreverentemusic.com/wp-content/uploads/2020/09/jose-madero-2-1200x1200-1.jpg?resize=940%2C940&ssl=1'}} />
                  </View>
                  
                  <View style={{flexDirection:'row'}}>
                  <Image style={{ width: 120, height: 150, margin:2 }} source={{uri:'https://i0.wp.com/irreverentemusic.com/wp-content/uploads/2020/09/jose-madero-2-1200x1200-1.jpg?resize=940%2C940&ssl=1'}} />
                  <Image style={{ width: 120, height: 150 , margin:2}} source={{uri:'https://i0.wp.com/irreverentemusic.com/wp-content/uploads/2020/09/jose-madero-2-1200x1200-1.jpg?resize=940%2C940&ssl=1'}} />
                  <Image style={{ width: 120, height: 150 , margin:2}} source={{uri:'https://i0.wp.com/irreverentemusic.com/wp-content/uploads/2020/09/jose-madero-2-1200x1200-1.jpg?resize=940%2C940&ssl=1'}} />
                  </View>

  </View>
);
};

export default Buscar; 

const styles = StyleSheet.create({
view: {
  margin: 10,
  marginBottom: 50,
  height:5
},
});