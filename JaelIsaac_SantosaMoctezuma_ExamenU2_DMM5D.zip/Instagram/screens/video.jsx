import { Text } from "react-native";

Video = () =>{
    return (
      <Text>Hola</Text>
    );
  }
  
  export default Video; 