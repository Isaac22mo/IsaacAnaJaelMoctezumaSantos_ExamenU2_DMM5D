import { MaterialIcons } from "@expo/vector-icons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { Text, View } from "react-native"
import Interfaz from "./interfaz";
import Perfil from "./perfil";
import Buscar from "./buscar";
import Mas from "./mas";
import Video from "./video";

const Tab = createBottomTabNavigator();

Inicio = () =>{

    return(
        <Tab.Navigator initialRouteName="Interfaz">
            <Tab.Screen component={Interfaz} name="Interfaz" options={{
                headerShown: false, tabBarActiveTintColor:'black',
                tabBarInactiveTintColor:'gray', tabBarLabelStyle:{fontSize:0},
                tabBarIcon:({size, color}) =>(
                    <MaterialIcons name="home" color={color} size={size}/>
                )
            }}/>

            <Tab.Screen component={Buscar} name="Buscar" options={{
                headerShown: false, tabBarActiveTintColor:'black',
                tabBarInactiveTintColor:'gray', tabBarLabelStyle:{fontSize:0},
                tabBarIcon:({size, color}) =>(
                    <MaterialIcons name="search" color={color} size={size}/>
                )
            }}/>    

            <Tab.Screen component={Perfil} name="Perfil" options={{
                        headerShown: false, tabBarActiveTintColor:'black',
                        tabBarInactiveTintColor:'gray', tabBarLabelStyle:{fontSize:0},
                        tabBarIcon:({size, color}) =>(
                            <MaterialIcons name="person" color={color} size={size}/>
                        )
            }}/>
        </Tab.Navigator>
    )
}

export default Inicio;