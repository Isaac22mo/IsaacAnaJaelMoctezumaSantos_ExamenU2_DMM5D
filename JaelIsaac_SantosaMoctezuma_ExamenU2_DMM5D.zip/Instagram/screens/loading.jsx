import { View } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { useEffect } from "react";
import { Image} from "@rneui/themed"

Loading = () =>{

    const navigation = useNavigation();

    useEffect(() => {
        const timeoudId = setTimeout(() =>{
            navigation.replace('Inicio');
        }, 1500);
        return () => clearTimeout(timeoudId);
    }, [navigation]);

    return(
        <View style={{flex:1, justifyContent: 'center', alignItems: 'center'}}>
            <Image style={{width:70, height:70}} source={require('../assets/instagram.png')} />
        </View>
    )
}

export default Loading;