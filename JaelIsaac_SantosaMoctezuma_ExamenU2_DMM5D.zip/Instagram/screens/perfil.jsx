import { Card } from "@rneui/base";
import { Image } from "@rneui/themed";
import { useState, useRef } from "react";
import { Modal, SectionList, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import LottieView from "lottie-react-native";

Perfil = () =>{

  const [publicaciones, setPublicaciones] = useState([
    { id: 1,imagenPublicacion: require('../assets/postGato.jpg'), corazon: require('../assets/mencanta.png'), mensaje: require('../assets/charlar.png'), enviar: require('../assets/enviar.png'), guardar: require('../assets/guardar.png') },
    { id: 2,imagenPublicacion: require('../assets/galgadot.jpg'), corazon: require('../assets/mencanta.png'), mensaje: require('../assets/charlar.png'), enviar: require('../assets/enviar.png'), guardar: require('../assets/guardar.png')  },
    { id: 3,imagenPublicacion: require('../assets/shakira.jpg'), corazon: require('../assets/mencanta.png'), mensaje: require('../assets/charlar.png'), enviar: require('../assets/enviar.png'), guardar: require('../assets/guardar.png')  },
  ]);

  const animation = useRef(null);
  const [img, setImg] = useState([
    'https://th.bing.com/th/id/OIP.PL1XmIWEwjoHqERguytyWQHaIy?rs=1&pid=ImgDetMain',
    'https://endorfinacultural.com/wp-content/uploads/2021/01/28056414_1971188826478161_6064365182470240653_n.jpg',
    'https://th.bing.com/th/id/OIP.kjqNsGlZ_F4scwbxfE7vWAD5D5?rs=1&pid=ImgDetMain',
    'https://lastfm.freetls.fastly.net/i/u/ar0/3d46cd698fa82cafb840d40cdd8bab85.jpg',
    'https://s3.amazonaws.com/bit-photos/large/9417402.jpeg',
    'https://th.bing.com/th/id/OIP.5plXMdFxWYML5gqREbAZfwHaJ_?rs=1&pid=ImgDetMain',
  ]);

  const [modalVisible, setModalVisible] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);

  const openModal = (post) => {
    setSelectedPost(post);
    setModalVisible(true);
  };

  const closeModal = () => {
    setSelectedPost(null);
    setModalVisible(false);
  };
  
  const [imagen, setImagenSeleccionada] = useState(null);
  const [modal, setModal] = useState(false);

  const closeM = () => {
    setModal(false);
  }

  const openM = (uri) => {
    setImagenSeleccionada(uri)
    setModal(true);
  }

    return (
      <View style={styles.container}>
        <View style={styles.headerContainer}>
          <Text style={styles.instagramText}>Instagram</Text>
          <View style={styles.imagesContainer}>
            <Image source={require('../assets/mencanta.png')} style={styles.image} />
            <Image source={require('../assets/menu.png')}style={[styles.image, { marginLeft: 10 }]} />
          </View>
        </View>

        <View style={{width:'100%', justifyContent:'space-between'}}>
          <View style={{marginTop:5, flexDirection:'row', justifyContent:'space-between'}}>
            <Image style={styles.imagenP} source={require('../assets/postGato.jpg')}/>

            <View style={{alignItems:'center', justifyContent:'space-between', flexDirection:'row'}}>
              <View style={{alignItems:'center', marginRight:18}}>
                <Text>6</Text>
                <Text>Publicaciones</Text>
              </View>

              <View style={{alignItems:'center', marginRight:18}}>
                <Text>90</Text>
                <Text>Seguidores</Text>
              </View>

              <View style={{alignItems:'center', marginRight:30}}>
                <Text>700</Text>
                <Text>Seguidos</Text>                
              </View>

            </View>

          </View>

          <Text style={{fontSize:20, alignItems:'center', marginLeft: 15, marginBottom:10}}>Jaely</Text>
        </View>

        <View>
      <View style={{height:90}}>
      <SectionList
        sections={[{ data: img }]}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() =>{openM(item)}}>
          <View style={{ justifyContent: 'center', alignItems: 'center', margin: 7 }}>
            <Image 
              style={styles.imagenE}
              source={{ uri: item }}
            />
            <Text style={{color: 'black', fontSize: 10, marginBottom: 2}}>Usuario</Text>
          </View>
          </TouchableOpacity>
          
        )}
        horizontal={true}
      />

      <Modal animationType='slide' visible={modal} transparent={true}>
                  <View>
                  <View style={styles.ModalView}>
                      <Image style={styles.imgModal} source={{uri: imagen}}/>    
                        <TouchableOpacity onPress={closeM}>
                          <Text>Cerrar</Text>
                        </TouchableOpacity>
                  </View>

                  </View>
      </Modal>
    

      </View>
      
              
                  <View style={{flexDirection:'row'}}>
                    <TouchableOpacity onLongPress={()=>openModal()}>
                      <Image style={{ width: 120, height: 150, margin:2 }} source={require('../assets/postGato.jpg')} />
                    </TouchableOpacity>    
                    <TouchableOpacity onLongPress={() => openModal()}>
                      <Image style={{ width: 120, height: 150, margin:2 }} source={require('../assets/galgadot.jpg')} />
                    </TouchableOpacity>
                    <TouchableOpacity onLongPress={() => openModal()}>
                      <Image style={{ width: 120, height: 150, margin:2 }} source={require('../assets/shakira.jpg')} />
                    </TouchableOpacity>
                  </View>
                
                  <View style={{flexDirection:'row'}}>
                    <TouchableOpacity onLongPress={() => openModal()}>
                      <Image style={{ width: 120, height: 150, margin:2 }} source={require('../assets/postGato.jpg')} />
                    </TouchableOpacity>    
                    <TouchableOpacity onLongPress={() => openModal()}>
                      <Image style={{ width: 120, height: 150, margin:2 }} source={require('../assets/galgadot.jpg')} />
                    </TouchableOpacity>
                    <TouchableOpacity onLongPress={() => openModal()}>
                      <Image style={{ width: 120, height: 150, margin:2 }} source={require('../assets/shakira.jpg')} />
                    </TouchableOpacity>
                  </View>
                
              
        </View>



                
      <Modal animationType='slide' visible={modalVisible} transparent={true}>
          <View>
          <View style={styles.ModalView}>
              <Image style={styles.imgModal} source={{uri: selectedPost}}/>    
                <TouchableOpacity onPress={closeModal}>
                  <Text>Cerrar</Text>
                </TouchableOpacity>
          </View>

          </View>
      </Modal>

     
      </View>
    );
  }
  
  export default Perfil; 
  
  const styles = StyleSheet.create({
    container:{
      flex:1,
      alignItems:'center',
      justifyContent:'center',
      backgroundColor:'white',
      marginTop:-140,

    },
    headerContainer: {
      backgroundColor:'white',
      width: '100%',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginLeft: 3,

    },
    instagramText: {
      color: 'black',
      fontSize: 30,
      marginLeft:10
    },
    imagesContainer: {
      marginRight: 10,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    image: {
      width: 20,
      height: 20,
    },
    cardContainer: {
      borderRadius: 0,
      alignItems:'center',
    },
    modalView: {
      marginTop: 150,
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 20,
      padding: 35,
      shadowColor: '#000',
      justifyContent:'center',
      alignItems:'center',
      shadowOffset: {
        width: 1,
        height: 2,
      },
      shadowOpacity: 20,
      shadowRadius: 4,
      elevation: 2,
    },
    cardreactions: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:'space-between',
    },
    guardarContainer: {
      position: 'relative',
      marginLeft: 0,
    },
    sectionContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    imagenP: {
      width: 60,
      height: 60,
      margin: 10,
      borderRadius: 50,
      paddingTop: 2
    },
    imagenE: {
      width: 50,
      height: 50,
      borderColor: '#fff',
      margin: 5,
      borderRadius: 50,
    },
    ModalView: {
      marginTop: 150,
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 20,
      padding: 35,
      shadowColor: '#000',
      justifyContent:'center',
      alignItems:'center',
      shadowOffset: {
        width: 1,
        height: 2,
      },
      shadowOpacity: 20,
      shadowRadius: 4,
      elevation: 2,
    },
    imgModal: {
      height: 300,
      width: 200,
      justifyContent: 'center',
      alignItems: 'center'
    },
  });