import { Button, Card, Image } from '@rneui/themed';
import { useState, useRef } from 'react';
import { SectionList, Text, View, StyleSheet , Modal, ScrollView, TouchableOpacity} from "react-native";
import LottieView from "lottie-react-native";

Interfaz = () => {
  const [publicaciones, setPublicaciones] = useState([
    { id: 1, autor: 'Jaely', imagenAutor: require('../assets/postGato.jpg'), imagenPublicacion: require('../assets/postGato.jpg'), corazon: require('../assets/mencanta.png'), mensaje: require('../assets/charlar.png'), enviar: require('../assets/enviar.png'), guardar: require('../assets/guardar.png') },
    { id: 2, autor: 'Juan', imagenAutor: require('../assets/avatar.png'), imagenPublicacion: require('../assets/galgadot.jpg'), corazon: require('../assets/mencanta.png'), mensaje: require('../assets/charlar.png'), enviar: require('../assets/enviar.png'), guardar: require('../assets/guardar.png')  },
    { id: 3, autor: 'sweeet_catsmania', imagenAutor: require('../assets/avatar.png'), imagenPublicacion: require('../assets/shakira.jpg'), corazon: require('../assets/mencanta.png'), mensaje: require('../assets/charlar.png'), enviar: require('../assets/enviar.png'), guardar: require('../assets/guardar.png')  },
  ]);

 const [modalVisible, setModalVisible] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);

  const openModal = (post) => {
    setSelectedPost(post);
    setModalVisible(true);
  };

  const closeModal = () => {
    setSelectedPost(null);
    setModalVisible(false);
  };

  const [img, setImg] = useState([
    'https://th.bing.com/th/id/OIP.PL1XmIWEwjoHqERguytyWQHaIy?rs=1&pid=ImgDetMain',
    'https://endorfinacultural.com/wp-content/uploads/2021/01/28056414_1971188826478161_6064365182470240653_n.jpg',
    'https://th.bing.com/th/id/OIP.kjqNsGlZ_F4scwbxfE7vWAD5D5?rs=1&pid=ImgDetMain',
    'https://lastfm.freetls.fastly.net/i/u/ar0/3d46cd698fa82cafb840d40cdd8bab85.jpg',
    'https://s3.amazonaws.com/bit-photos/large/9417402.jpeg',
    'https://th.bing.com/th/id/OIP.5plXMdFxWYML5gqREbAZfwHaJ_?rs=1&pid=ImgDetMain',
  ]);

  const [imagen, setImagenSeleccionada] = useState(null);
  const [modal, setModal] = useState(false);

  const closeM = () => {
    setModal(false);
  }

  const openM = (uri) => {
    setImagenSeleccionada(uri)
    setModal(true);
  }

  const animation = useRef(null);
  return (
    <View style={{ flex: 1, justifyContent: 'space-between', backgroundColor:'white' }}>
     <View style={styles.headerContainer}>
        <Text style={styles.instagramText}>Instagram</Text>
        <View style={styles.imagesContainer}>
          <Image source={require('../assets/mencanta.png')} style={styles.image} />
          <Image source={require('../assets/messenger.png')}style={[styles.image, { marginLeft: 10 }]} />
        </View>
      </View>
      
      <SectionList
        sections={[{ data: img }]}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() =>{openM(item)}}>
          <View style={{ justifyContent: 'center', alignItems: 'center', margin: 5 }}>
            <Image 
              style={styles.imagenE}
              source={{ uri: item }}
            />
            <Text style={{color: 'black', fontSize: 10, marginBottom: 20}}>Usuario</Text>
          </View>
          </TouchableOpacity>
          
        )}
        horizontal={true}
      />
      
      <Modal animationType='slide' visible={modal} transparent={true}>
          <View>
          <View style={styles.ModalView}>
              <Image style={styles.imgModal} source={{uri: imagen}}/>    
                <TouchableOpacity onPress={closeM}>
                  <Text>Cerrar</Text>
                </TouchableOpacity>
          </View>

          </View>
      </Modal>

      <SectionList
        sections={[{ title: 'Header', data: ['Header']}, { data: publicaciones }]}
        keyExtractor={(item, index) => item.id ? item.id.toString() : index.toString()}
        renderItem={({ item }) => (
          item !== 'Header' && (
            <TouchableOpacity onLongPress={() => openModal(item)}>
              <Card containerStyle={styles.cardContainer}>
                <Card.Title>
                  <View style={styles.cardtitle}>
                    <Image style={styles.circleImageU} source={item.imagenAutor} />
                    <Text style={{ textAlign: 'left' }}>{item.autor}</Text>
                  </View>
                </Card.Title>
                <Card.Divider />
                <Image style={{ width: 280, height: 450 }} source={item.imagenPublicacion} />
                <Card.Divider />
                <View style={styles.cardreactions}>
                  <Image style={{ width: 20, height: 20 }} source={item.corazon} />
                  <Image style={{ width: 23, height: 23 }} source={item.mensaje} />
                  <Image style={{ width: 20, height: 20 }} source={item.enviar} />
                  <View style={styles.guardarContainer}>
                    <Image style={{ width: 20, height: 20 }} source={item.guardar} />
                  </View>
                </View>
                <Card.Divider />
              </Card>
            </TouchableOpacity>
          )
        )}
       
      />
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={closeModal}
      >
        <View style={styles.modalView}>
          

          {selectedPost && (
            <>
              <Image style={{ width: 280, height: 350 }} source={selectedPost.imagenPublicacion} />
                <Card.Divider />
                <View style={styles.cardreactions}>
                  <Image style={{ width: 20, height: 20 }} source={selectedPost.corazon} />
                  <Image style={{ width: 23, height: 23 }} source={selectedPost.mensaje} />
                  <Image style={{ width: 20, height: 20 }} source={selectedPost.enviar} />
                  <View style={styles.guardarContainer}>
                    <Image style={{ width: 20, height: 20 }} source={selectedPost.guardar} />
                  </View>
                </View>
              
            </>
          )}
          <TouchableOpacity onPress={closeModal}>
            <Text>Cerrar</Text>
          </TouchableOpacity>
        </View>
      </Modal>

    </View>
  );
};

export default Interfaz;

const styles = StyleSheet.create({
    modalView: {
      marginTop: 150,
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 20,
      padding: 35,
      shadowColor: '#000',
      justifyContent:'center',
      alignItems:'center',
      shadowOffset: {
        width: 1,
        height: 2,
      },
      shadowOpacity: 20,
      shadowRadius: 4,
      elevation: 2,
    },
    cerrar: {
      alignItems: 'flex-end',
      justifyContent: 'flex-end'
    }, 
    circleContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginVertical: 20,
      marginLeft:4,
      
    },
    circleImage: {
      width: 50,
      height: 50,
      borderRadius: 25, 
      borderColor:'pink',
      borderWidth: 2,
      justifyContent:'space-between'
    },
    cardContainer: {
      borderRadius: 0,
      alignItems:'center',
    },
    image: {
      width: 20,
      height: 20,
    },
    cardreactions: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:'space-between',
     

    },
    guardarContainer: {
      position: 'relative',
      marginLeft: 0,

      
    },
     headerContainer: {
      marginTop: 40,
      width: '100%',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginLeft: 3,
      backgroundColor:'white',
    },
    instagramText: {
      color: 'black',
      fontSize: 30,
    },
    imagesContainer: {
      marginRight: 10,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    cardtitle: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'flex-start',
      marginRight: 70,
    },
    circleImageU: {
      width: 25,
      height: 25,
      borderRadius: 25,
      marginRight: 6,
    },
    imagenE: {
      width: 50,
      height: 50,
      borderColor: '#fff',
      margin: 10,
      borderRadius: 50,
      borderColor: '#E50195',
      borderWidth: 1,
      paddingTop: 2
    },
    ModalView: {
      marginTop: 150,
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 20,
      padding: 35,
      shadowColor: '#000',
      justifyContent:'center',
      alignItems:'center',
      shadowOffset: {
        width: 1,
        height: 2,
      },
      shadowOpacity: 20,
      shadowRadius: 4,
      elevation: 2,
    },
    imgModal: {
      height: 300,
      width: 200,
      justifyContent: 'center',
      alignItems: 'center'
    },
    cerrarModal: {
      justifyContent: 'flex-end',
      alignItems: 'flex-end',
    },
  });