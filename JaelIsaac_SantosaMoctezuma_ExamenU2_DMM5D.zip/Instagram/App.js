import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';

import Loading from './screens/loading';
import Inicio from './screens/inicio';

const Stack = createNativeStackNavigator();

App = () =>{
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Loading'>
        <Stack.Screen name='Loading' component={Loading} options={{headerShown:false}}/>
        <Stack.Screen name='Inicio' component={Inicio} options={{headerShown:false}}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App; 

